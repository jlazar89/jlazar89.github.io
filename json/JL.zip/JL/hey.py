#pip install <Module Name>
#Command : python3 -W ignore hey.py

import requests
import os
import json
import zipfile

# create a simple JSON array
# jsonString = '[{"title":"A to Z Letter","zip_url":"https://api.wastickerapp.co/images/stickers/zip/207.zip"},{"title":"Acronyms","zip_url":"https://api.wastickerapp.co/images/stickers/zip/160.zip"},{"title":"Mr. Bean","zip_url":"https://api.wastickerapp.co/images/stickers/zip/112.zip"}]'

# change the JSON string into a JSON object
with open('response.json') as f:
    jsonObject = json.load(f)

# print the keys and values
for key in jsonObject["data"]:
    dictName = key["title"]
    if not os.path.exists(dictName):
        os.makedirs(dictName)
        os.chdir(dictName)
        file_name = key["title"]+".zip"
        print(file_name)
        with open(file_name, 'wb') as f:
            resp = requests.get(key["zip_url"], verify=False)
            f.write(resp.content)
            zip_ref = zipfile.ZipFile(file_name, 'r')
            zip_ref.extractall()
            zip_ref.close()
        os.remove(file_name)
        os.chdir("..")


