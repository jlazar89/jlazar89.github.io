package collectionsexample;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListSortingTest {

    public static void main(String[] args) {

        ArrayList<String> mArrayList = new ArrayList<>();
        mArrayList.add("Captain America");
        mArrayList.add("Captain Marvel");
        mArrayList.add("Iron man");
        mArrayList.add("Black widow");
        mArrayList.add("Scarlett witch");

        System.out.println("Array output before modification: \n" + mArrayList.toString() + " \n");

        Collections.sort(mArrayList);
        System.out.println("Array output after modification: \n" + mArrayList.toString() + " \n");

        Collections.sort(mArrayList, Collections.reverseOrder());
        System.out.println("Array output in reverse order after modification: \n" + mArrayList.toString() + " \n");
    }
}
