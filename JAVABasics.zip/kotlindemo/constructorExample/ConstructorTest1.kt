package kotlindemo.constructorExample

//this demo is not completed
class Person(var firstName: String, var age: Int = 2) {

//    init {
//        this.firstName = firstName + "SSS"
//        this.age = age * 10
//    }

    constructor(lastName: String, firstName: String, age: Int = 2) : this(firstName, age) {
        println("Secondary constructor called lastname is $lastName firstname is $firstName and age is $age")
    }

    constructor(firstName: String,age: Int,rollno:Int):this(firstName,age){
        println("Secondary constructor called with firstname is $firstName, age is $age and roll number is $rollno")
    }
}

fun main(args: Array<String>) {
//    val mPerson1 = Person("Smit", 5)
//    println("Name: ${mPerson1.firstName} Age: ${mPerson1.age}")
//
//    val mPerson2 = Person("Albert Enistine")
//    println("Name: ${mPerson2.firstName} Age: ${mPerson2.age}")

    val mPerson3 = Person("Satodia", "Smit",5)
    println("Name: ${mPerson3.firstName} Age: ${mPerson3.age}")

}

