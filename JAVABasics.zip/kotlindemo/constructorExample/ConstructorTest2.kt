package kotlindemo.constructorExample

open class Parent {


    constructor(name: String, id: Int) {
        println("Parent first constructor")
    }

    constructor(name: String, id: Int, pass: String) {
        println("Parent second constructor")
    }
}

class Child : Parent {
    constructor(name: String, id: Int) : super("sd",3) {
        println("Child first constructor")
    }

    constructor(name: String, id: Int, pass: String) : super(name, id, "password") {
        println("Child second constructor")
    }
}

fun main(args: Array<String>) {
    val obj1 = Child("Ashu", 101)
//    val obj2 = Child("Ashu", 101, "mypassword")
}