package interfaceexample;

interface Bank {
    int id = 5; // public static final
    float rateOfInterest(); // public abstract
}

interface PostOffice {
    int postalCodes();
}

class SBI implements Bank {
    public void printVariable() {
        System.out.println("Variable value is " + id);
    }

    @Override
    public float rateOfInterest() {
        return 5.0f;
    }
}

class HDFC implements Bank {
    @Override
    public float rateOfInterest() {
        return 6.56f;
    }
}

class AXIS implements Bank {
    @Override
    public float rateOfInterest() {
        return 7.99f;
    }
}

class PostBank implements Bank, PostOffice {
    @Override
    public float rateOfInterest() {
        return 3.6f;
    }

    @Override
    public int postalCodes() {
        return 11254;
    }
}

class InterfaceTest {
    public static void main(String[] args) {
        Bank a = new SBI();
        printer("Rate of interest in interfaceexample.SBI is: " + a.rateOfInterest());

        SBI sbi = new SBI();
        sbi.printVariable();

        Bank b = new HDFC();
        printer("Rate of interest in interfaceexample.HDFC is: " + b.rateOfInterest());

        Bank c = new AXIS();
        printer("Rate of interest in interfaceexample.AXIS is: " + c.rateOfInterest());

        PostOffice p = new PostBank();
        printer("Postal code is " + p.postalCodes());

        Bank d = new PostBank();
        printer("Rate of interest is " + d.rateOfInterest());

        PostBank pb = new PostBank();
        printer("Rate of interest in POSTBANK is  " + pb.rateOfInterest() + " Postal code is " + pb.postalCodes());

        Bank x = () -> 12.5f;
        printer("Rate of interest in Xbank is: " + x.rateOfInterest());
    }

    static void printer(String s) {
        System.out.println(s);
    }
}
