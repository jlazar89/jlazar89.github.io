package inheritanceexample;

class Animal {
    void eat() {
        System.out.println("Eating in parent class");
    }
}

class Dog extends Animal {
    void bark() {
        System.out.println("Barking in child class");
    }

    void eat(){
        super.eat();
        System.out.println("Eating in child class");
    }

    void eat(int foodItems){
        System.out.println("Eating "+foodItems+" food items in child class");
    }
}

class BabyDog extends Dog{
    void weeping(){
        System.out.println("Weeping in child class");
    }
}

class InheritanceTest {
    public static void main(String args[]) {
        System.out.println("\n // Operations on inheritanceexample.Dog object");

        Dog d = new Dog();
        d.bark();
        d.eat();
        d.eat(2);

        System.out.println("\n // Operations on inheritanceexample.BabyDog object");

        BabyDog b = new BabyDog();
        b.bark();
        b.eat();
        b.eat(3);
        b.weeping();
    }
}
