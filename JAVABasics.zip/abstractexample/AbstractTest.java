package abstractexample;

abstract class Country {
    int i = 50;
    abstract String countryName();
}

abstract class State extends Country {
    abstract String stateName();
}

class India extends State {

    @Override
    String countryName() {

        return "India";
    }

    @Override
    String stateName() {
        return "Gujarat, Maharastra, Madhyapradesh";
    }
}

abstract class Bank {
    abstract float rateOfInterest();
}

class SBI extends Bank {
    @Override
    float rateOfInterest() {
        return 5.0f;
    }
}

class HDFC extends Bank {
    @Override
    float rateOfInterest() {
        return 6.65f;
    }
}

public class AbstractTest {

    public static void main(String[] args) {
        Bank a = new SBI();
        printer("Rate of interest in SBI is: " + a.rateOfInterest());

        Bank b = new HDFC();
        printer("Rate of interest in HDFC is: " + b.rateOfInterest());

        State s = new India();
        printer(s.stateName() + " " + s.countryName()+" "+s.i);
    }

    static void printer(String s) {
        System.out.println(s);
    }
}
