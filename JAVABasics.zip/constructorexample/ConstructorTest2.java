package constructorexample;


class vehicle{
    vehicle(){
        System.out.println("VEHICLE| Default constructor called");
    }

    vehicle(int i){
        this();
        System.out.println("VEHICLE| 1 Parameter constructor called");
    }

}

class Bike extends vehicle{

    Bike(){
        super(10);
        System.out.println("BIKE| Default constructor called");
    }

    Bike(int i){
        System.out.println("BIKE| 1 Parameter constructor called");
    }
}
public class ConstructorTest2 {
    public static void main(String[] args) {
        Bike b = new Bike();
    }
}
