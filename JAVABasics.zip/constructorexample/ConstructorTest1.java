package constructorexample;

/*
    A Java constructor cannot be abstract, static, final, and synchronized
*/

class Student {

    private int id;
    private String name;

    Student() {
        printer("Default constructor called");
    }

    Student(int id) {
        this.id = id;
        printer("Constructor with id " + id + " called");
    }

    Student(int id, String name) {
        this.id = id;
        this.name = name;
        printer("Constructor with id " + id + " and name " + name + "called");
    }

    static void printer(String s) {
        System.out.println(s);
    }
}

public class ConstructorTest1 {
    public static void main(String[] args) {
        Student ct1 = new Student();
        Student ct2 = new Student(1);
        Student ct3 = new Student(2, "Smit");
    }
}
