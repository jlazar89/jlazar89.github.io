package finalfinallyfinalize;

public class FinalFinallyFinalizeTest {

    public static void main(String[] args) {

        //Example of final
        final int x = 0;
        // x = 5; // will not work, as final variable can't be change

        //Example of finally
        try {
            throw new NullPointerException("Just another null pointer!!");
        } catch (NullPointerException e) {
            System.out.println("Exception catched " + e.toString());
        } finally {
            System.out.println("Finally block called");
        }

        FinalFinallyFinalizeTest f1 = new FinalFinallyFinalizeTest();
        f1 = null; // without nullifing object finalize method won't call
        System.gc();


    }

    //Example of finalize
    @Override
    @Deprecated
    protected void finalize() throws Throwable {
        super.finalize();
        System.out.println("Finalized method called");
    }
}
