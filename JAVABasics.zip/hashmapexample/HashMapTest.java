package hashmapexample;

import javafx.print.Printer;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class HashMapTest {
    public static void main(String[] args) {

        HashMap<Integer, String> mHashMap = new HashMap<>();
        mHashMap.put(1, "Android");
        mHashMap.put(2, "iOS");
        mHashMap.put(3, "React-Native");

        //printer("Hashmap data is "+mHashMap.toString());

        iterateHashMap0(mHashMap);
        iterateHashMap1(mHashMap);
        iterateHashMap2(mHashMap);
        removeFromHashMap(mHashMap);
        getVakueByKey(mHashMap,1);
    }

    //ITERATING OVER HASHMAP USING ENTRYSET
    //If you want only Key -> keySet()
    //If you want only Value -> values()
    public static void iterateHashMap0(HashMap aHashMap) {
        printer("\n //Output of iterateHashMap0");
        for (Object o : aHashMap.entrySet()) {
            Map.Entry mPair = (Map.Entry) o;
            printer("Key is: " + mPair.getKey() + " Value is: " + mPair.getValue());
        }
    }

    //ITERATING USING FOREACH AND VALUES
    public static void iterateHashMap1(HashMap aHashMap) {
        printer("\n //Output of iterateHashMap1");
        Collection<?> values = aHashMap.values();
        for (Object value : values) {
            printer("Value: " + value);
        }
    }

    //ITERATING USING FOREACH AND keySet
    public static void iterateHashMap2(HashMap aHashMap) {
        printer("\n //Output of iterateHashMap2");
        Collection<?> keys = aHashMap.keySet();
        for (Object key : keys) {
            printer("Key: " + key + " Value: " + aHashMap.get(key));
        }
    }

    //REMOVING OPERATION IN HASHMAP
    public static void removeFromHashMap(HashMap aHashMap) {
        printer("\n //Output of removeFromHashMap");
        printer("BEFORE REMOVING: " + aHashMap.toString());
        String valueOfRemovedItem = (String) aHashMap.remove(2);
        printer("Value of removed item is " + valueOfRemovedItem);
        printer("AFTER REMOVING VALID KEY: " + aHashMap.toString());
    }

    //GETTING ITEM USING KEY
    public static void getVakueByKey(HashMap mHashMap, int key){
        printer("\n //Output of getVakueByKey");
        String i = mHashMap.get(key).toString();
        printer("Value is "+i);
    }
    
    static void printer(String s){
        System.out.println(s);
    }


}
