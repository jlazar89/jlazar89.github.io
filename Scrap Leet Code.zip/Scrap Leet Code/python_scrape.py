from bs4 import BeautifulSoup

htmlStringArray = []
htmlHeader = "<html><body><table border=\"1\" style=\"width:100%\">"
htmlFooter = "</table></body></html>"
htmlStringArray.append("<tr>")
htmlStringArray.append("<td>"+"<b>"+"#"+"</b>"+"</td>")
htmlStringArray.append("<td>"+"<b>"+"Question"+"</b>"+"</td>")
htmlStringArray.append("<td>"+"<b>"+"Difficulty"+"</b>"+"</td>")


def parseTrData(tdData):
    htmlStringArray.append("<tr>")
    htmlStringArray.append("<td>"+tdData[1].string+"</td>")
    sample = (tdData[2]).find('a',href=True)
    htmlStringArray.append("<td>"+"<a href="+ "https://leetcode.com"+sample['href']+ ">" + sample.string + "</a></td>")
    htmlStringArray.append("<td>"+tdData[5].find("span").string+"</td>")


soup = BeautifulSoup(open("google.html"), 'html.parser')
tableData = soup.find("tbody", {"class": "reactable-data"}).findAll('tr')

for trData in tableData:
    parseTrData(trData.findAll('td'))

htmlBody = ''.join(htmlStringArray)
finlaHtmlString = htmlHeader + htmlBody + htmlFooter
Html_file= open("FinalFile.html","w")
Html_file.write(finlaHtmlString)
Html_file.close()